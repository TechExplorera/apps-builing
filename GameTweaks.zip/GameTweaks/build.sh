#!/data/data/com.termux/files/usr/bin/bash
# Compilación manual del módulo en Termux (sin Gradle)
# Uso: ANDROID_JAR=/ruta/android.jar ./build.sh
set -e
cd "$(dirname "$0")"

ANDROID_JAR="${ANDROID_JAR:-$HOME/android-sdk/platforms/android-34/android.jar}"
XPOSED_JAR="${XPOSED_JAR:-libs/api-82.jar}"
SRC=app/src/main
OUT=build-manual
KS="$HOME/.android/debug.keystore"

[ -f "$ANDROID_JAR" ] || { echo "Falta android.jar: $ANDROID_JAR"; exit 1; }
if [ ! -f "$XPOSED_JAR" ]; then
  mkdir -p libs
  wget -O "$XPOSED_JAR" https://api.xposed.info/de/robv/android/xposed/api/82/api-82.jar
fi

rm -rf $OUT && mkdir -p $OUT/classes $OUT/dex

# Manifest con package (aapt2 lo necesita fuera de Gradle)
sed 's|<manifest |<manifest package="com.peta.gametweaks" |' \
  $SRC/AndroidManifest.xml > $OUT/AndroidManifest.xml

echo "[1/5] Recursos"
aapt2 compile --dir $SRC/res -o $OUT/res.zip
aapt2 link -o $OUT/base.apk -I "$ANDROID_JAR" \
  --manifest $OUT/AndroidManifest.xml -A $SRC/assets \
  --min-sdk-version 26 --target-sdk-version 34 \
  --version-code 1 --version-name 1.0 $OUT/res.zip

echo "[2/5] Java"
javac -source 11 -target 11 -bootclasspath "$ANDROID_JAR" \
  -cp "$XPOSED_JAR" -d $OUT/classes $(find $SRC/java -name '*.java')

echo "[3/5] DEX"
d8 --lib "$ANDROID_JAR" --min-api 26 --output $OUT/dex \
  $(find $OUT/classes -name '*.class')

echo "[4/5] Empaquetar"
(cd $OUT/dex && zip -uq ../base.apk classes.dex)
zipalign -f 4 $OUT/base.apk $OUT/aligned.apk

echo "[5/5] Firmar"
if [ ! -f "$KS" ]; then
  mkdir -p "$(dirname "$KS")"
  keytool -genkeypair -keystore "$KS" -storepass android -keypass android \
    -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US"
fi
apksigner sign --ks "$KS" --ks-pass pass:android --key-pass pass:android \
  --out GameTweaks.apk $OUT/aligned.apk

echo "Listo: $(pwd)/GameTweaks.apk"

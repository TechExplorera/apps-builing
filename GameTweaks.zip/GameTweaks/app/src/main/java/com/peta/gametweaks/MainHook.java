package com.peta.gametweaks;

import android.os.Build;
import android.view.Display;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) {
        // Solo actúa en las apps marcadas en el scope del módulo
        if (lpparam.packageName.equals("com.peta.gametweaks")) return;
        Config.Profile p = Config.forPackage(lpparam.packageName);

        try { spoofBuild(p); } catch (Throwable t) { XposedBridge.log("GameTweaks build: " + t); }
        try { hookSystemProperties(p); } catch (Throwable t) { XposedBridge.log("GameTweaks props: " + t); }
        if (p.refreshRate > 0) {
            try { hookRefreshRate(p.refreshRate); } catch (Throwable t) { XposedBridge.log("GameTweaks hz: " + t); }
        }
        XposedBridge.log("GameTweaks activo en " + lpparam.packageName + " como " + p.model);
    }

    private void spoofBuild(Config.Profile p) {
        XposedHelpers.setStaticObjectField(Build.class, "BRAND", p.brand);
        XposedHelpers.setStaticObjectField(Build.class, "MANUFACTURER", p.manufacturer);
        XposedHelpers.setStaticObjectField(Build.class, "MODEL", p.model);
        XposedHelpers.setStaticObjectField(Build.class, "DEVICE", p.device);
        XposedHelpers.setStaticObjectField(Build.class, "PRODUCT", p.product);
    }

    private void hookSystemProperties(final Config.Profile p) {
        Class<?> sp = XposedHelpers.findClass("android.os.SystemProperties", null);
        XC_MethodHook hook = new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                String key = (String) param.args[0];
                if (key == null) return;
                switch (key) {
                    case "ro.product.brand": param.setResult(p.brand); break;
                    case "ro.product.manufacturer": param.setResult(p.manufacturer); break;
                    case "ro.product.model": param.setResult(p.model); break;
                    case "ro.product.device": param.setResult(p.device); break;
                    case "ro.product.name": param.setResult(p.product); break;
                }
            }
        };
        XposedBridge.hookAllMethods(sp, "get", hook);
    }

    private void hookRefreshRate(float hz) {
        XposedHelpers.findAndHookMethod(Display.class, "getRefreshRate",
                XC_MethodReplacement.returnConstant(hz));
    }
}

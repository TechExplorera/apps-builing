package com.peta.gametweaks;

import java.util.HashMap;
import java.util.Map;

/** Perfiles de dispositivo. Edita aquí o añade paquetes nuevos. */
public class Config {
    public static class Profile {
        final String brand, manufacturer, model, device, product;
        final float refreshRate; // 0 = no tocar
        Profile(String brand, String manufacturer, String model, String device, String product, float hz) {
            this.brand = brand; this.manufacturer = manufacturer; this.model = model;
            this.device = device; this.product = product; this.refreshRate = hz;
        }
    }

    // Perfil por defecto: se aplica a CUALQUIER juego que actives en el scope de LSPosed
    static final Profile DEFAULT = new Profile(
            "samsung", "samsung", "SM-S928B", "e3q", "e3qxxx", 120f); // Galaxy S24 Ultra

    // Perfiles específicos por paquete (opcional)
    static final Map<String, Profile> PER_APP = new HashMap<>();
    static {
        // PER_APP.put("com.netease.newspike", new Profile(...));
    }

    static Profile forPackage(String pkg) {
        Profile p = PER_APP.get(pkg);
        return p != null ? p : DEFAULT;
    }
}
